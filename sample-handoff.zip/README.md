# Booking allocator — sample handoff

Compact handoff slice for the booking case shown in the portfolio.

This package demonstrates the structure of a transferable project state rather than a production export.

Contents:
- `01-process-map.md` — observed workflow and decision points
- `02-constraints.md` — explicit admissibility rules and operator rights
- `03-scenarios.md` — small executable/test scenarios
- `04-decision-trace.md` — example of reason, evidence, status and supersession
- `05-next-state.md` — open questions and next tests
