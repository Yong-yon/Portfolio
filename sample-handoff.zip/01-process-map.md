# 01 / Process map

## Goal
Assign a party to an admissible table configuration without hiding the rules that make the placement valid.

## Current workflow
1. Receive party size, requested time and duration.
2. Read current occupancy.
3. Exclude unavailable tables.
4. Generate single-table and allowed combined-table candidates.
5. Reject candidates below required capacity.
6. Rank remaining candidates by fit / operational cost.
7. Operator chooses one admissible candidate.
8. Commit the booking and preserve the constraint set used for the decision.

## Decision boundary
Ranking recommends. It does not remove operator authority to select another admissible candidate.
