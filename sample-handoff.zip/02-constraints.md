# 02 / Constraint model

## Inputs
- party_size
- start_time
- duration
- current_occupancy
- table_capacity
- allowed_table_combinations

## Hard constraints
- occupied tables cannot be allocated;
- total capacity must be >= party size;
- only allowed combinations may be generated;
- an empty admissible set means commit is impossible.

## Soft ranking
Prefer lower unused capacity and fewer joined tables.

## Authority
System: generate and rank candidates.
Operator: choose an admissible candidate and commit.
