# 04 / Decision trace

## Decision D-0042
Status: active

### Decision
Separate candidate generation from booking commit.

### Reason
The system can calculate possible placements without having authority to choose on behalf of the operator.

### Evidence
Observed workflow contains manual judgement between several valid placements.

### Realized in
Candidate list + ranking + explicit operator selection.

### Supersedes
D-0031: automatically commit the top-ranked candidate.

### Residue
Ranking policy and tie-breaking still require validation against live operational use.
