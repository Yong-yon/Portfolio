# 05 / Next state

## Open questions
- Which table combinations are operationally forbidden despite sufficient capacity?
- Does duration affect future candidate availability enough to change ranking?
- Which exceptions require manager approval?

## Next tests
1. Validate combinations against real floor constraints.
2. Run edge cases around overlapping durations.
3. Observe operator overrides and classify reasons.
4. Decide which override reasons should become modelled constraints.

## Known limit
This package is a portfolio handoff specimen, not a production booking system export.
