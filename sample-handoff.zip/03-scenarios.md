# 03 / Scenarios

## Scenario A — single-table fit
Party: 4
Available table: S3 / capacity 4
Expected: S3 is admissible and ranks above oversized options.

## Scenario B — combination required
Party: 5
No free table with capacity >= 5
Two compatible free tables total capacity 6
Expected: the pair is admissible; smaller invalid options are absent.

## Scenario C — no admissible state
Party: 8
All valid large combinations occupied
Expected: candidate set is empty; commit is unavailable.

## Risk being tested
Whether changing inputs changes the admissible space correctly, rather than merely changing the visual state of the interface.
